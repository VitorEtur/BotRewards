import threading
import time
import pyautogui
import os
import keyboard
import random

py = pyautogui
numero_aleatorio = random.randint(1, 9999999)

def confirm():
    resposta = py.confirm(text='Deseja iniciar o bot?', buttons=['Sim', 'Não'])
    if resposta == 'Sim':
        return True
    else:
        return False

if confirm():
    py.alert('O Bot será iniciado, lembre-se que para pausar o bot aperte a tecla "Q" repetidas vezes até que a automação pare')
    py.hotkey('winleft','r')
    py.write('msedge')
    py.press('enter')
    time.sleep(0.5)
    py.typewrite('https://rewards.bing.com/redeem/pointsbreakdown')
    py.press('enter')
    py.hotkey('ctrl','t')
    pyautogui.typewrite(str(numero_aleatorio))
    py.press('enter')
    py.hotkey('ctrl','w')

    def x():
        while True:
            numero_aleatorio = random.randint(1, 9999999)
            py.hotkey('ctrl','t')
            pyautogui.typewrite(str(numero_aleatorio))
            py.press('enter')
            py.hotkey('ctrl','w')
            py.press('f5')

    def y(): ## Tranca ao apertar q
        while True:
            if keyboard.is_pressed('q'): 
                os._exit(0)

    threading.Thread(target=y).start() ## Roda duas funções ao mesmo tempo      
    threading.Thread(target=x).start() ## Roda duas funções ao mesmo tempo
